from darkfly.darkfly import menu

if __name__ == '__main__':
    menu()

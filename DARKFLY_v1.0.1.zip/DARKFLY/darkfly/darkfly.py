#!/usr/bin/env python3
"""DARKFLY - cross-platform security tools installer.
Use only on systems and networks you own or are authorized to assess.
"""
import json, os, platform, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CATALOG_FILE = ROOT / "catalog.json"
HOME_TOOLS = Path.home() / ".darkfly" / "tools"
MANIFEST = Path.home() / ".darkfly" / "installed.json"

def load_catalog():
    with CATALOG_FILE.open(encoding="utf-8") as f:
        return json.load(f)

def detect_platform():
    if "ANDROID_ROOT" in os.environ or "com.termux" in os.environ.get("PREFIX", ""):
        return "termux"
    if platform.system().lower() == "linux":
        try:
            data = Path("/etc/os-release").read_text(encoding="utf-8").lower()
            if any(x in data for x in ("kali", "debian", "ubuntu")):
                return "kali"
        except OSError:
            pass
    return "unknown"

def run(command, check=False):
    print("\n$ " + " ".join(command))
    try:
        return subprocess.run(command, check=check).returncode == 0
    except FileNotFoundError:
        print("[ERROR] Required command not found: " + command[0])
        return False
    except KeyboardInterrupt:
        print("\n[STOPPED] Operation interrupted.")
        return False

def ensure_manager(env):
    if env == "termux":
        if not shutil.which("pkg"):
            print("[ERROR] Termux package manager (pkg) was not found.")
            return False
        return True
    if env == "kali":
        if not shutil.which("apt-get"):
            print("[ERROR] apt-get was not found.")
            return False
        if os.geteuid() != 0 and not shutil.which("sudo"):
            print("[ERROR] Run as root or install sudo.")
            return False
        return True
    print("[ERROR] Unsupported platform. Use Kali Linux or Termux.")
    return False

def package_command(env, package):
    if env == "termux":
        return ["pkg", "install", "-y", package]
    prefix = [] if os.geteuid() == 0 else ["sudo"]
    return prefix + ["apt-get", "install", "-y", package]

def update_index(env):
    if env == "termux":
        return run(["pkg", "update", "-y"])
    prefix = [] if os.geteuid() == 0 else ["sudo"]
    return run(prefix + ["apt-get", "update"])

def installed_manifest():
    try:
        return json.loads(MANIFEST.read_text(encoding="utf-8"))
    except Exception:
        return {}

def save_manifest(data):
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text(json.dumps(data, indent=2), encoding="utf-8")

def install_packages(items, env):
    if not ensure_manager(env):
        return
    print("\n[INFO] Updating package indexes...")
    update_index(env)
    manifest = installed_manifest()
    success = 0
    for item in items:
        package = item[env]
        print("\n[INSTALL] " + item["name"] + " (" + package + ")")
        if run(package_command(env, package)):
            manifest[item["id"]] = {"name": item["name"], "package": package, "platform": env}
            success += 1
        else:
            print("[SKIP] Could not install " + item["name"] + ". Check package availability.")
    save_manifest(manifest)
    print("\n[SUMMARY] Package installs completed: " + str(success) + "/" + str(len(items)))

def clone_repositories(items, env):
    if not shutil.which("git"):
        print("[INFO] Git is missing. Installing Git first...")
        git_pkg = "git"
        if not ensure_manager(env):
            return
        run(package_command(env, git_pkg))
    HOME_TOOLS.mkdir(parents=True, exist_ok=True)
    success = 0
    for item in items:
        if env not in item["platforms"]:
            print("[SKIP] " + item["name"] + " is not listed for this platform.")
            continue
        dest = HOME_TOOLS / item["id"]
        print("\n[DOWNLOAD] " + item["name"])
        if dest.exists() and (dest / ".git").exists():
            ok = run(["git", "-C", str(dest), "pull", "--ff-only"])
        else:
            ok = run(["git", "clone", "--depth", "1", item["repo"], str(dest)])
        if ok:
            success += 1
        else:
            print("[WARN] Download failed for " + item["name"])
    print("\n[SUMMARY] Repositories downloaded/updated: " + str(success) + "/" + str(len(items)))

def all_install(catalog, env):
    print("\n[PLAN] Install all compatible packages and download all listed source repositories.")
    print("[INFO] No Wi-Fi auditing or GPU-dependent tools are included.")
    print("[INFO] Review the package list before continuing.")
    print("Packages: " + ", ".join(x["name"] for x in catalog["packages"]))
    print("GitHub sources: " + ", ".join(x["name"] for x in catalog["github"]))
    print("[INFO] Starting bulk installation because option 1 was selected.")
    install_packages(catalog["packages"], env)
    clone_repositories(catalog["github"], env)

def show_tools(catalog):
    print("\nAVAILABLE PACKAGE TOOLS")
    for i, item in enumerate(catalog["packages"], 1):
        print(f"{i:02d}. [{item['category']}] {item['name']} - {item['description']}")
    print("\nGITHUB SOURCE TOOLS")
    for item in catalog["github"]:
        print(f" - {item['name']} - {item['description']}")

def install_one(catalog, env):
    show_tools(catalog)
    raw = input("\nEnter package tool number: ").strip()
    if not raw.isdigit() or not 1 <= int(raw) <= len(catalog["packages"]):
        print("[ERROR] Invalid selection.")
        return
    install_packages([catalog["packages"][int(raw)-1]], env)

def search_tools(catalog):
    q = input("Search keyword: ").strip().lower()
    matches = [x for x in catalog["packages"] if q in (x["name"]+" "+x["category"]+" "+x["description"]).lower()]
    if not matches:
        print("[INFO] No matching tools found.")
    for x in matches:
        print(f"- {x['name']} [{x['category']}]")

def doctor(env):
    print("\nSYSTEM DIAGNOSTICS")
    print("Platform: " + env)
    print("Python: " + sys.version.split()[0])
    print("Architecture: " + platform.machine())
    for cmd in ("pkg", "apt-get", "git", "python3", "curl", "wget"):
        print(f"{cmd}: {'FOUND' if shutil.which(cmd) else 'NOT FOUND'}")
    print("Tools directory: " + str(HOME_TOOLS))

def menu():
    catalog = load_catalog()
    env = detect_platform()
    while True:
        print("\n" + "=" * 54)
        print("                 DARKFLY TOOLKIT")
        print("          CROSS-PLATFORM INSTALLER")
        print("=" * 54)
        print("Platform: " + env.upper())
        print("\n[1] INSTALL ALL (PACKAGES + GITHUB SOURCES)")
        print("[2] LIST AVAILABLE TOOLS")
        print("[3] INSTALL ONE PACKAGE TOOL")
        print("[4] DOWNLOAD / UPDATE GITHUB SOURCES")
        print("[5] SEARCH TOOLS")
        print("[6] SYSTEM DIAGNOSTICS")
        print("[0] EXIT")
        choice = input("\nDARKFLY > ").strip()
        if choice == "1":
            all_install(catalog, env)
        elif choice == "2":
            show_tools(catalog)
        elif choice == "3":
            install_one(catalog, env)
        elif choice == "4":
            clone_repositories(catalog["github"], env)
        elif choice == "5":
            search_tools(catalog)
        elif choice == "6":
            doctor(env)
        elif choice == "0":
            print("Goodbye.")
            break
        else:
            print("[ERROR] Invalid option.")

if __name__ == "__main__":
    try:
        menu()
    except KeyboardInterrupt:
        print("\n[STOPPED] DARKFLY closed safely.")

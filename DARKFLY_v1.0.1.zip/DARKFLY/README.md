# DARKFLY Toolkit

A cross-platform command-line installer for Kali Linux and Termux.

## Features

- English-only terminal interface.
- Bulk installation with option `1`.
- Installs compatible packages through `apt-get` on Kali or `pkg` on Termux.
- Downloads selected GitHub source repositories automatically.
- Skips unsupported platforms and records package installation results.
- No Wi-Fi auditing tools or GPU-dependent tools are included.

## Included package tools

Nmap, WHOIS, DNS utilities, cURL, Wget, Git, Python 3, jq, OpenSSL, Netcat,
Traceroute, IP Route tools, Ping utilities, Tcpdump, File, Binutils, XXD,
Ripgrep, Tree, and Tmux.

## Included GitHub source projects

- testssl.sh
- WhatWeb
- Wafw00f

## Requirements

- Kali Linux or Termux.
- Python 3.
- Internet connection for package and source downloads.
- On Kali, run as root or have `sudo` installed.
- On Termux, install Python using `pkg install python`.

## Run

```bash
python3 run_darkfly.py
```

Choose:

- `1` to install all compatible packages and download all listed GitHub sources.
- `2` to list the catalog.
- `3` to install one package tool.
- `4` to download/update GitHub sources.
- `5` to search tools.
- `6` to run diagnostics.
- `0` to exit.

For bulk installation, type `YES` when prompted. This prevents accidental large downloads.

## GitHub source handling

Repositories are cloned into `~/.darkfly/tools/`. If a repository already exists,
DARKFLY attempts a fast-forward-only update. Review third-party source code before
running it. DARKFLY downloads source code; it does not silently execute downloaded tools.

## Safety

Use these tools only on systems and networks you own or are explicitly authorized
to assess. The catalog intentionally excludes Wi-Fi auditing, GPU-dependent
password-cracking tools, phishing kits, spam tools, malware, and credential theft
utilities.

Package names and availability can vary by OS release and repository configuration.
If a package is unavailable on your device, DARKFLY reports the failure and continues.
